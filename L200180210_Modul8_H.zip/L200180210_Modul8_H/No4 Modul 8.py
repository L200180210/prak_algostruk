import heapq

class Queue(object):
    def __init__(self):
        self.qlist = []

    def isEmpty(self):
        return len(self) == 0

    def __len__(self):
        return len(self.qlist)

    def enqueue(self, data):
        self.qlist.append(data)

    def dequeue(self):
        assert not self.isEmpty(), "Antrian sedang kosong."
        return self.qlist.pop(0)
    
    def getFrontMost(self):
        return self.qlist[-1]

    def getRearMost(self):
        return self.qlist[0]

class PriorityQueue(object):
    def __init__(self):
        self.qlist= []

    def __len__(self):
        return len(self.qlist)

    def isEmpty(self):
        return len(self)==0

    def enqueue(self, data, priority):
        heapq.heappush(self.qlist, (priority, data))
        self.qlist.sort()

    def dequeue(self):
        return self.qlist.pop(-1)

    def getFrontMost(self):
        return self.qlist[-1]

    def getRearMost(self):
        return self.qlist[0]

class _PriorityQEntry(object):
    def __init__(self, data, priority):
        self.item = data
        self.priority = priority

Q = Queue()
Q.enqueue('qqqqq')
Q.enqueue('wwwww')
Q.enqueue('eeeee')

print("===QUEUE===")
print("enqueue: ",Q.qlist)
Q.dequeue()
print("dequeue", Q.qlist)

print("item paling depan:", Q.getFrontMost())
print("item peling belakang:", Q.getRearMost())

    
P = PriorityQueue()

P.enqueue('qqqqq', 5)
P.enqueue('wwwww', 1)
P.enqueue('eeeee', 2)

print("\n===PRIORITY QUEUE===")
print("enqueue: ", P.qlist)
P.dequeue()
print("dequeue: ", P.qlist)

print("item paling depan:", Q.getFrontMost())
print("item peling belakang:", Q.getRearMost())
