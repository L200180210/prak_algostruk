import timeit
import time
import matplotlib.pyplot as plt


def carilurus(wadah, target):
    n = len(wadah)
    for i in range(n):
        if wadah[i] == target:
            return True
    return False

def tim():
    z=100
    a = [8, 7, 2, 1, 3, 2, 10]
    awal = time.time()
    U = carilurus(a, z)
    akhir=time.time()
    print("Worst case")
    print("mengurutkan %d bilangan, memerlukan %8.7f detik" %(U,akhir-awal))

tim()
